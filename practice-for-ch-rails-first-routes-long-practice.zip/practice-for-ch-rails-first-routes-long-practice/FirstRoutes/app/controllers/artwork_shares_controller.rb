class ArtworkSharesController < ApplicationController
end
