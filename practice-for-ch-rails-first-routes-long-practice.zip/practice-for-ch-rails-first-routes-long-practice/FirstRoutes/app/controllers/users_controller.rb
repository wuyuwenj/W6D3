class UsersController < ApplicationController

    # C POST
    def create
        @user = User.new(user_params)
        if @user.save
          render json: @user
        else
          render json: @user.errors.full_messages, status: :unprocessable_entity
        end
    end

    # R, GET all
    def index
        # get all the user objects
        @users = User.all
        # render all those objects on Postman
        render json: @users
    end

    # R, GET one
    def show
        # @specific_user is a User Instance, found by its id
        @specific_user = User.find(params[:id])
        render json: @specific_user
    end

    # U PATCH
    def update
        # we want to update the user's database row
        # then render newly updated user
        @user = User.find(params[:id])
        if @user.update(user_params)
            redirect_to user_url(@user)
        else
            render json: @user.errors.full_messages, status: :unprocessable_entity
        end 
    end

    # D DESTROY
    def destroy
        # we want to find the specific user to delete
        @user = User.find(params[:id])

        # if the user was already deleted?
        @user.destroy
            # render that user
        redirect_to users_url
        
    end

    private

    def user_params
        params.require(:user).permit(:name, :email)
    end
end
