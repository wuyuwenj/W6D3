# Table name: artworks
#
#  title      :string           not null
#  image_url  :text             not null
#  artist_id  :bigint           not null

class Artwork < ApplicationRecord

    validates :title, uniqueness: { scope: :artist_id }

    belongs_to :user,
        foreign_key: :artist_id,
        class_name: :User

    # technically, this is the number of people that have this artwork shared to them
    has_many :views,
        foreign_key: :artwork_id,
        class_name: :ArtworkShare
        dependent: :destroy
        
end
