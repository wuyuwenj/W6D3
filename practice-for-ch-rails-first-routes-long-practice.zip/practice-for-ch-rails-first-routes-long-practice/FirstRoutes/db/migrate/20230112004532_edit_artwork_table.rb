class EditArtworkTable < ActiveRecord::Migration[7.0]
  def change
    remove_column :artworks, :artist_id_id

    add_reference :artworks, :artist, null: false, foreign_key: { to_table: :users }

    add_index :artworks, [:title, :artist_id], unique: true
  end
end
